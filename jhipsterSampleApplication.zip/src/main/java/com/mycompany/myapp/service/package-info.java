/**
 * Service layer beans.
 */
package com.mycompany.myapp.service;
